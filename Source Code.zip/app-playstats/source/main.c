// The guide I followed for building this app was here: https://switch.homebrew.guide/homebrew_dev/introduction.html
// The following code is a modified version of the example programs found at https://github.com/switchbrew/switch-examples
// The specific program I used as a base was applet/app-playstats. I used this program because it was committed 8 months ago and uses the latest version of libnx.
// The environment used was a Windows machine that has msys2 installed via the devkitPro graphical installer found here: https://github.com/devkitPro/installer/releases.
// msys2 was installed with all the preset installation options, but the most important component is "Switch Development". Make sure it's checked.
// Compiled with make

// Include the most common headers from the C standard library
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Include the main libnx system header, for Switch development
#include <switch.h>

void toggle_cheats(char arg) {
    char* file_path = "sdmc:/atmosphere/config/system_settings.ini";
    FILE *file = fopen(file_path, "r+");
    if (file == NULL) {
        printf("Could not open file %s", file_path);
        return;
    }

    char line[256];
    if(arg == '0'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "dmnt_cheats_enabled_by_default = u8!0x1") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('0', file); // replace 1 with 0
                break;
            }
        }
    }
    if(arg == '1'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "dmnt_cheats_enabled_by_default = u8!0x0") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('1', file); // replace 0 with 1
                break;
            }
        }
    }
    fclose(file);
}

void toggle_usb(char arg) {
    char* file_path = "sdmc:/atmosphere/config/system_settings.ini";
    FILE *file = fopen(file_path, "r+");
    if (file == NULL) {
        printf("Could not open file %s", file_path);
        return;
    }

    char line[256];
    if(arg == '0'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "usb30_force_enabled = u8!0x0") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('1', file); // replace 1 with 0
                break;
            }
        }
    }
    if(arg == '1'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "usb30_force_enabled = u8!0x1") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('0', file); // replace 0 with 1
                break;
            }
        }
    }
    fclose(file);
}

void toggle_dns(char arg) {
    char* file_path = "sdmc:/atmosphere/config/system_settings.ini";
    FILE *file = fopen(file_path, "r+");
    if (file == NULL) {
        printf("Could not open file %s", file_path);
        return;
    }

    char line[256];
    if(arg == '0'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "enable_dns_mitm = u8!0x0") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('1', file); // replace 1 with 0
                break;
            }
        }
    }
    if(arg == '1'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "enable_dns_mitm = u8!0x1") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('0', file); // replace 0 with 1
                break;
            }
        }
    }
    fclose(file);
}

void toggle_errupload(char arg) {
    char* file_path = "sdmc:/atmosphere/config/system_settings.ini";
    FILE *file = fopen(file_path, "r+");
    if (file == NULL) {
        printf("Could not open file %s", file_path);
        return;
    }

    char line[256];
    if(arg == '0'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "upload_enabled = u8!0x0") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('1', file); // replace 1 with 0
                break;
            }
        }
    }
    if(arg == '1'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "upload_enabled = u8!0x1") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('0', file); // replace 0 with 1
                break;
            }
        }
    }
    fclose(file);
}

void toggle_sdlog(char arg) {
    char* file_path = "sdmc:/atmosphere/config/system_settings.ini";
    FILE *file = fopen(file_path, "r+");
    if (file == NULL) {
        printf("Could not open file %s", file_path);
        return;
    }

    char line[256];
    if(arg == '0'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "enable_sd_card_logging = u8!0x0") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('1', file); // replace 1 with 0
                break;
            }
        }
    }
    if(arg == '1'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "enable_sd_card_logging = u8!0x1") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('0', file); // replace 0 with 1
                break;
            }
        }
    }
    fclose(file);
}

void toggle_autoreportclear(char arg) {
    char* file_path = "sdmc:/atmosphere/config/system_settings.ini";
    FILE *file = fopen(file_path, "r+");
    if (file == NULL) {
        printf("Could not open file %s", file_path);
        return;
    }

    char line[256];
    if(arg == '0'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "disable_automatic_report_cleanup = u8!0x0") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('1', file); // replace 1 with 0
                break;
            }
        }
    }
    if(arg == '1'){
        while (fgets(line, sizeof(line), file)) {
            if (strstr(line, "disable_automatic_report_cleanup = u8!0x1") != NULL) {
                fseek(file, -3, SEEK_CUR); // go back 2 characters
                fputc('0', file); // replace 0 with 1
                break;
            }
        }
    }
    fclose(file);
}

/// Main program entrypoint
int main(int argc, char* argv[])
{
    // This example uses a text console, as a simple way to output text to the screen.
    consoleInit(NULL);

    // Configure our supported input layout: a single player with standard controller styles
    padConfigureInput(1, HidNpadStyleSet_NpadStandard);

    // Initialize the default gamepad (which reads handheld mode inputs as well as the first connected controller)
    PadState pad;
    padInitializeDefault(&pad);

    printf("system_settings.ini Editor\n\n");

    Result rc=0;
    bool initflag=0;

    // Only needed when using the cmds which require the Uid.
    AccountUid preselected_uid={0};
    rc = accountInitialize(AccountServiceType_Application);
    if (R_SUCCEEDED(rc)) {
        rc = accountGetPreselectedUser(&preselected_uid);
        accountExit();
    }
    if (R_FAILED(rc)) printf("Failed to get user: 0x%x\n", rc);

    // Not needed if you just want to use the applet cmds.
    if (R_SUCCEEDED(rc)) {
        rc = pdmqryInitialize();
        if (R_FAILED(rc)) printf("pdmqryInitialize(): 0x%x\n", rc);
        if (R_SUCCEEDED(rc)) initflag = true;
    }

    if (initflag) printf("Press A to access main menu, or + to exit.\n\n");
    

    // Main loop
    int currentOption = 0; // start with first option
    int optionsCount = 6; // total number of options
    bool cheatsEnabled = true;
    bool usbEnabled = false;
    bool dnsEnabled = true;
    bool erruploadEnabled = false;
    bool sdlogEnabled = true;
    bool autoreportclearEnabled = false;
    while (appletMainLoop())
    {
        // Scan the gamepad. This should be done once for each frame
        padUpdate(&pad);

        // padGetButtonsDown returns the set of buttons that have been
        // newly pressed in this frame compared to the previous one
        u64 kDown = padGetButtonsDown(&pad);

        if (kDown & HidNpadButton_Plus)
            break; // break in order to return to hbmenu

        if (kDown & HidNpadButton_Up) {
            currentOption = (currentOption - 1 + optionsCount) % optionsCount; // go up
        }

        if (kDown & HidNpadButton_Down) {
            currentOption = (currentOption + 1) % optionsCount; // go down
        }

        if (kDown & HidNpadButton_A) {
            if (currentOption == 0) {
                cheatsEnabled = !cheatsEnabled; // toggle cheats
                toggle_cheats(cheatsEnabled ? '1' : '0');
            } else if (currentOption == 1) {
                usbEnabled = !usbEnabled; // toggle usb
                toggle_usb(usbEnabled ? '1' : '0'); // toggle USB
            }
             else if (currentOption == 2) {
                dnsEnabled = !dnsEnabled; // toggle usb
                toggle_dns(dnsEnabled ? '1' : '0'); // toggle USB
            }
             else if (currentOption == 3) {
                erruploadEnabled = !erruploadEnabled; // toggle usb
                toggle_errupload(erruploadEnabled ? '1' : '0'); // toggle USB
            }
             else if (currentOption == 4) {
                sdlogEnabled = !sdlogEnabled; // toggle usb
                toggle_sdlog(sdlogEnabled ? '1' : '0'); // toggle USB
            }
            else if (currentOption == 5) {
                autoreportclearEnabled = !autoreportclearEnabled; // toggle usb
                toggle_autoreportclear(autoreportclearEnabled ? '1' : '0'); // toggle USB
            }
            
            // Clear the console
            consoleClear();

            // Print all options
            printf("cheats_enabled_by_default: (%s)\n", cheatsEnabled ? "X" : " ");
            printf("USB3.0_enabled: (%s)\n", usbEnabled ? "X" : " ");
            printf("dns_mitm_enabled: (%s)\n", dnsEnabled ? "X" : " ");
            printf("error_report_uploads_enabled (%s)\n", erruploadEnabled ? "X" : " ");
            printf("sd_card_logging_enabled (%s)\n", sdlogEnabled ? "X" : " ");
            printf("automatic_report_cleanup_disabled: (%s)\n", autoreportclearEnabled ? "X" : " ");
        }

        // Update the console, sending a new frame to the display
        consoleUpdate(NULL);
    }


    pdmqryExit();

    // Deinitialize and clean up resources used by the console (important!)
    consoleExit(NULL);
    return 0;
}
